export const environment = {
    production: false,
    name: 'test',
    test: true
  };
  